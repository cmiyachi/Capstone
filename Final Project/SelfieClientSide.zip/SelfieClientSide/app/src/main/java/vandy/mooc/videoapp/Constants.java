package vandy.mooc.videoapp;


public final class Constants  {

    static final String TEST_URL = "https://10.0.2.2:8443";
    static final  String CLIENT_ID = "mobile";
}
